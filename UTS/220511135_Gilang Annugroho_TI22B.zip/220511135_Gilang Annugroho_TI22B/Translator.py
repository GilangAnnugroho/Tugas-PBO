import tkinter as tk
from tkinter import ttk
from googletrans import Translator

def translate_text():
    text_to_translate = entry.get()
    selected_language = destination_language.get()
    translator = Translator()
    translated_text = translator.translate(text_to_translate, dest=selected_language)
    translated_box.delete(1.0, tk.END)  # Menghapus hasil sebelumnya
    translated_box.insert(tk.END, translated_text.text)

# Membuat GUI
root = tk.Tk()
root.title("Aplikasi Translator Gilang")

# Stylesheet dan setting font
bg_color = "#f0f0f0"  # Warna latar belakang utama
font_style = ('Arial', 12)  # Setting font utama
label_bg = bg_color  # Warna latar belakang label
entry_bg = "white"  # Warna latar belakang entry
button_bg = "blue"  # Warna latar belakang tombol
button_fg = "white"  # Warna teks tombol
text_bg = "silver"  # Warna latar belakang kotak teks


root.configure(bg=bg_color)  # Atur latar belakang aplikasi

label = tk.Label(root, text="Masukkan Teks:", bg=label_bg, font=font_style)
label.pack()

entry = tk.Entry(root, bg=entry_bg, font=font_style)
entry.pack()

destination_language_label = tk.Label(root, text="Pilih Bahasa Tujuan:", bg=label_bg, font=font_style)
destination_language_label.pack()

# Menambahkan pilihan bahasa
languages = ['en', 'su', 'jw']  # Kode bahasa yang akan ditampilkan
destination_language = ttk.Combobox(root, values=languages, state="readonly", font=font_style)
destination_language.pack()

translate_button = tk.Button(root, text="Translate", command=translate_text, bg=button_bg, fg=button_fg, font=font_style)
translate_button.pack()

# Mengatur wrap pada kolom teks untuk mengikuti panjang teks
translated_box = tk.Text(root, height=10, width=40, wrap=tk.WORD, bg=text_bg, font=font_style)
translated_box.pack()

root.mainloop()
